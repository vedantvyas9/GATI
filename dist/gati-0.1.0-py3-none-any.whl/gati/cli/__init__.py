"""GATI CLI for managing backend and dashboard."""
from .main import main

__all__ = ["main"]
