# GATI - Local-First Observability for AI Agents

<div align="center">

[![PyPI version](https://badge.fury.io/py/gati.svg)](https://badge.fury.io/py/gati)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Track, debug, and understand your AI agents - all data stays on your machine**

[Quick Start](#quick-start) • [Features](#features) • [Documentation](#documentation) • [Examples](#examples)

</div>

---

## 🎯 What is GATI?

GATI (Graph-based Agent Trace Intelligence) is an open-source observability platform for AI agents that keeps all your data local. Track LLM calls, tool usage, agent state, and execution flows without sending any data to external services.

### Why GATI?

- **🔒 Privacy-First**: All data stored locally - no external services required
- **📊 Visual Dashboard**: Beautiful React dashboard to explore agent traces
- **🔌 Zero Instrumentation**: Drop-in compatibility with LangChain, LangGraph, and custom agents
- **🎨 Execution Graphs**: Visualize complex agent workflows as interactive graphs
- **⚡ Real-Time Monitoring**: Watch your agents execute in real-time
- **🐳 One-Command Setup**: Start everything with `gati start`

---

## 🚀 Quick Start

### Installation

```bash
pip install gati
```

### Start GATI Services

```bash
# Start backend, dashboard, and database
gati start

# Or run in background
gati start -d
```

This starts:
- **Backend API**: http://localhost:8000
- **Dashboard**: http://localhost:3000
- **PostgreSQL Database**: localhost:5432

### Instrument Your Code

```python
from gati import observe

# Initialize GATI (one-time setup)
observe.init(backend_url="http://localhost:8000")

# Option 1: Decorator (recommended)
@observe.trace_agent(name="my-agent")
def my_agent_function(query: str):
    # Your agent code here
    return response

# Option 2: Context manager
with observe.agent(name="my-agent"):
    # Track LLM calls
    with observe.llm_call(model="gpt-4", inputs={"prompt": "Hello"}):
        response = llm.call("Hello")
        observe.log_output(response)
```

### View in Dashboard

Open http://localhost:3000 to see your agent traces, execution graphs, and metrics!

---

## ✨ Features

### 🎯 Comprehensive Tracking

- **LLM Calls**: Track all calls to OpenAI, Anthropic, or custom LLMs
- **Tool Usage**: Monitor function calls, API requests, database queries
- **Agent State**: Capture agent decision-making and state transitions
- **System Prompts**: Track system prompts and their evolution
- **Errors & Retries**: Automatic error tracking with stack traces

### 🔌 Framework Integration

#### LangChain
```python
from gati.integrations.langchain import GATICallbackHandler

chain = LLMChain(llm=llm, callbacks=[GATICallbackHandler()])
chain.run("What is AI?")
```

#### LangGraph
```python
from gati.integrations.langgraph import instrument_langgraph

app = create_langgraph()
instrumented_app = instrument_langgraph(app, run_name="my-graph")
```

#### Custom Agents
```python
@observe.trace_agent(name="custom-agent")
@observe.track_step(step_type="reasoning")
def reason_about(query: str):
    # Your logic
    return result
```

### 📊 Dashboard Features

- **Run Explorer**: Browse all agent runs with filtering and search
- **Execution Graph**: Interactive visualization of agent execution flow
- **Timeline View**: See events in chronological order
- **Metrics**: Track token usage, latency, error rates
- **System Prompts**: View and compare system prompts across runs

---

## 📦 What's Included?

When you install GATI, you get:

1. **Python SDK** - Lightweight instrumentation library
2. **Backend API** - FastAPI server for data storage
3. **Dashboard** - React web app for visualization
4. **Database** - PostgreSQL for persistent storage
5. **CLI Tools** - Manage services with `gati` command

Everything runs locally via Docker Compose - no external dependencies!

---

## 🛠️ CLI Commands

```bash
# Start all services
gati start              # Interactive mode
gati start -d           # Detached mode

# Stop services
gati stop

# View status
gati status

# View logs
gati logs               # All services
gati logs backend       # Specific service
gati logs -f backend    # Follow logs
```

---

## 🔧 Configuration

### Environment Variables

Create a `.env` file (or copy `.env.example`):

```bash
# Backend
DATABASE_URL=postgresql://user:password@localhost:5432/gati
BACKEND_PORT=8000

# Dashboard
DASHBOARD_PORT=3000
VITE_BACKEND_URL=http://localhost:8000

# Telemetry (opt-in, anonymous)
GATI_TELEMETRY_URL=https://gati-mvp-telemetry.vercel.app/api/metrics
GATI_TELEMETRY=false  # Disable entirely
```

### Docker Compose

For advanced configurations, edit `docker-compose.yml`:

```yaml
services:
  backend:
    ports:
      - "8000:8000"
    environment:
      DATABASE_URL: postgresql://...
```

---

## 📚 Examples

### LangChain Agent

```python
from langchain.agents import initialize_agent, Tool
from langchain.llms import OpenAI
from gati import observe
from gati.integrations.langchain import GATICallbackHandler

# Initialize GATI
observe.init(backend_url="http://localhost:8000")

# Create agent with GATI callback
llm = OpenAI(temperature=0)
tools = [Tool(name="Calculator", func=calculator, description="...")]
agent = initialize_agent(
    tools,
    llm,
    callbacks=[GATICallbackHandler(run_name="math-agent")]
)

# Run agent - automatically tracked!
agent.run("What is 15 * 23?")
```

### LangGraph Workflow

```python
from langgraph.graph import Graph
from gati.integrations.langgraph import instrument_langgraph

# Create graph
graph = Graph()
graph.add_node("researcher", research_node)
graph.add_node("writer", writer_node)
graph.add_edge("researcher", "writer")

app = graph.compile()

# Instrument with GATI
instrumented_app = instrument_langgraph(app, run_name="research-writer")

# Run - all steps tracked automatically!
instrumented_app.invoke({"query": "AI trends 2024"})
```

### Custom Agent

```python
from gati import observe

observe.init(backend_url="http://localhost:8000")

@observe.trace_agent(name="research-agent")
class ResearchAgent:
    @observe.track_step(step_type="search")
    def search(self, query: str):
        # Search implementation
        results = search_api(query)
        observe.log_output(results)
        return results
    
    @observe.track_step(step_type="analyze")
    def analyze(self, results):
        # Analysis implementation
        with observe.llm_call(model="gpt-4"):
            analysis = llm.analyze(results)
            observe.log_output(analysis)
        return analysis
```

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────┐
│           Your Application                   │
│  (LangChain, LangGraph, Custom Agents)      │
└─────────────────┬───────────────────────────┘
                  │
                  │ GATI SDK
                  ↓
┌─────────────────────────────────────────────┐
│         GATI Backend (FastAPI)              │
│  - Receives events via REST API             │
│  - Stores in PostgreSQL                     │
│  - Serves dashboard data                    │
└─────────────────┬───────────────────────────┘
                  │
                  ↓
┌─────────────────────────────────────────────┐
│          PostgreSQL Database                 │
│  - Runs, Events, System Prompts             │
│  - All data stored locally                  │
└─────────────────────────────────────────────┘
                  ↑
                  │
┌─────────────────┴───────────────────────────┐
│          Dashboard (React)                   │
│  - Run Explorer                             │
│  - Execution Graphs                         │
│  - Metrics & Analytics                      │
│  http://localhost:3000                      │
└─────────────────────────────────────────────┘
```

---

## 🔐 Privacy & Telemetry

GATI is **privacy-first**:
- ✅ All agent data stays on your machine
- ✅ No external API calls for core functionality
- ✅ You control the database

**Anonymous Telemetry** (opt-in by default):
- Tracks: SDK version, framework usage, event counts
- **Does NOT track**: Your prompts, responses, or any sensitive data
- Disable: Set `GATI_TELEMETRY=false` in `.env`

---

## 📖 Documentation

- **[Installation Guide](docs/installation.md)** - Detailed setup instructions
- **[SDK Reference](docs/sdk-reference.md)** - Complete API documentation
- **[Integration Guides](docs/integrations/)** - LangChain, LangGraph, custom
- **[Dashboard Guide](docs/dashboard.md)** - Using the web interface
- **[Architecture](docs/architecture.md)** - System design and components
- **[Contributing](docs/contributing.md)** - How to contribute

---

## 🤝 Contributing

We love contributions! See [CONTRIBUTING.md](docs/contributing.md) for guidelines.

### Development Setup

```bash
# Clone repository
git clone https://github.com/gati-ai/gati-sdk.git
cd gati-sdk

# Install in editable mode
pip install -e "sdk[dev]"

# Start services for development
docker-compose up

# Run tests
pytest sdk/tests/
```

---

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgments

Built with:
- [FastAPI](https://fastapi.tiangolo.com/) - Backend framework
- [React](https://react.dev/) - Dashboard UI
- [PostgreSQL](https://www.postgresql.org/) - Database
- [LangChain](https://langchain.com/) - LLM framework integration
- [D3.js](https://d3js.org/) - Graph visualizations

---

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/gati-ai/gati-sdk/issues)
- **Discussions**: [GitHub Discussions](https://github.com/gati-ai/gati-sdk/discussions)
- **Email**: support@gati.dev

---

<div align="center">

**Made with ❤️ for the AI community**

[⭐ Star on GitHub](https://github.com/gati-ai/gati-sdk) | [📚 Read the Docs](https://docs.gati.dev) | [🐦 Follow on Twitter](https://twitter.com/gati_ai)

</div>
