# GATI Dashboard

A modern, responsive web dashboard for monitoring and analyzing AI agents built with the GATI SDK. Built with React, TypeScript, Tailwind CSS, and Vite.

## Features

- **Agent Monitoring**: View all registered agents with aggregated metrics
- **Run Tracking**: Detailed view of individual agent execution runs
- **Event Timeline**: Chronological visualization of events within each run
- **Token Analysis**: Track input/output token usage and costs
- **Dark Mode**: Toggle between light and dark themes
- **Responsive Design**: Works seamlessly on desktop and tablet devices

## Tech Stack

- **React 18**: UI library
- **TypeScript**: Type-safe development
- **Vite**: Fast build tool and dev server
- **Tailwind CSS**: Utility-first CSS framework
- **React Router**: Client-side routing
- **Axios**: HTTP client for API communication
- **Recharts**: Data visualization (for future enhancements)
- **Reactflow**: Graph visualization (for future enhancements)

## Setup

### Prerequisites

- Node.js 18+ (LTS recommended)
- npm or yarn package manager
- GATI Backend API running on `http://localhost:8000`

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

The dashboard will be available at `http://localhost:3000`

### Build for Production

```bash
npm run build
```

This creates an optimized production build in the `dist/` directory.

## Project Structure

```
src/
   components/           # Reusable React components
      Header.tsx       # Top navigation bar with logo and dark mode toggle
      AgentCard.tsx    # Card component for displaying agent summary
      RunDetail.tsx    # Detailed view of a single run
      Timeline.tsx     # Chronological event timeline visualization
   pages/               # Page-level components
      AgentsList.tsx   # Main agents listing page
      AgentDetail.tsx  # Agent detail page with run list sidebar
   services/
      api.ts          # Axios client and API service methods
   types/
      index.ts        # TypeScript interfaces for API types
   styles/
      globals.css     # Global Tailwind CSS and custom styles
   App.tsx             # Root component with routing
   index.tsx           # Entry point
```

## API Integration

The dashboard connects to the GATI Backend API. Configure the API base URL in [src/services/api.ts](src/services/api.ts).

### Key API Endpoints Used

- `GET /api/agents` - List all agents
- `GET /api/agents/{agent_name}` - Get agent details
- `GET /api/agents/{agent_name}/runs` - Get agent runs
- `GET /api/runs/{run_id}` - Get run details
- `GET /api/runs/{run_id}/timeline` - Get event timeline for run
- `GET /api/metrics/summary` - Get global metrics

## Styling

The dashboard uses Tailwind CSS with a custom theme:

- **Primary Color**: Navy Blue (#1e3a8a)
- **Font**: Garamond serif for headings, system sans-serif for body
- **Dark Mode**: Fully supported with automatic theme detection

Customize theme colors in [tailwind.config.js](tailwind.config.js).

## Development

### Code Quality

```bash
# TypeScript type checking
npm run type-check

# Format code (if prettier is installed)
npm run format
```

### Environment Variables

Create a `.env.local` file for local configuration:

```
VITE_API_BASE_URL=http://localhost:8000
```

## Browser Support

- Chrome/Edge: Latest versions
- Firefox: Latest versions
- Safari: Latest versions
- Mobile browsers: iOS Safari 14+, Chrome Android

## Performance

- Optimized bundle size with code splitting
- Lazy loading for route components
- Efficient API caching with axios
- Dark mode toggle without page reload

## Contributing

When adding new features:

1. Create components in the appropriate directory
2. Define types in `src/types/index.ts`
3. Add API methods to `src/services/api.ts`
4. Update routing in `src/App.tsx` if needed
5. Follow the existing code style and naming conventions

## Deployment

### Docker

A Dockerfile is provided for containerized deployment. Build and run:

```bash
docker build -t gati-dashboard .
docker run -p 3000:3000 gati-dashboard
```

### Static Hosting

The built `dist/` folder can be served from any static hosting service (Netlify, Vercel, AWS S3, etc.).

## Future Enhancements

- Metrics charts and graphs using Recharts
- Execution graph visualization using Reactflow
- Real-time updates with WebSocket
- Advanced filtering and search
- Run comparison tools
- Export functionality

## License

See LICENSE file in repository root.
